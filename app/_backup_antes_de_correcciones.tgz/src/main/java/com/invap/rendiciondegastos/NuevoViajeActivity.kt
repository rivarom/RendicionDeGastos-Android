package com.invap.rendiciondegastos

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
// import com.google.firebase.auth.ktx.auth // Eliminado
// import com.google.firebase.ktx.Firebase // Eliminado
import com.invap.rendiciondegastos.databinding.ActivityNuevoViajeBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class NuevoViajeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNuevoViajeBinding
    // Modificado: El ID ahora es Long. 0L (cero) significa que es un viaje nuevo.
    private var idViajeAEditar: Long = 0L
    private val imputacionesList = mutableListOf<Imputacion>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNuevoViajeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Habilita el modo Edge-to-Edge
        WindowCompat.setDecorFitsSystemWindows(window, false)

// Aplica el relleno para las barras del sistema
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        cargarOpciones()
        configurarCampoDeFecha()
        configurarValidacionEnTiempoReal() // 1. Nueva función para validación

        // Modificado: Se obtiene el ID como Long. Si no se pasa, el valor por defecto es 0L.
        idViajeAEditar = intent.getLongExtra(EXTRA_VIAJE_ID, 0L)

        // Modificado: Se comprueba si el ID es diferente de 0L
        if (idViajeAEditar != 0L) {
            // Modo Edición
            binding.editTextNombreViaje.setText(intent.getStringExtra(EXTRA_VIAJE_NOMBRE))
            binding.editTextFechaViaje.setText(intent.getStringExtra(EXTRA_VIAJE_FECHA))
            binding.autoCompleteMonedaViaje.setText(intent.getStringExtra(EXTRA_VIAJE_MONEDA_DEFECTO), false)
            val pt = intent.getStringExtra(EXTRA_VIAJE_IMPUTACION_PT)
            val wp = intent.getStringExtra(EXTRA_VIAJE_IMPUTACION_WP)
            if (pt != null && wp != null) {
                binding.autoCompleteImputacionViaje.setText("PT: $pt / WP: $wp", false)
            }
            binding.buttonGuardar.text = "Actualizar Viaje"
        } else {
            // Sugerencia para el nombre del viaje
            binding.editTextNombreViaje.hint = "Nombre del viaje (ej: Destino, Mes)"
        }

        binding.buttonGuardar.setOnClickListener {
            if (validarCampos()) {
                guardarViaje()
            } else {
                Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show()
            }
        }

        validarCampos() // Llamada inicial para establecer el estado del botón
    }

    private fun configurarValidacionEnTiempoReal() {
        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                validarCampos()
            }
        }

        binding.editTextNombreViaje.addTextChangedListener(textWatcher)
        binding.autoCompleteImputacionViaje.addTextChangedListener(textWatcher)
        binding.autoCompleteMonedaViaje.addTextChangedListener(textWatcher)
    }

    private fun validarCampos(): Boolean {
        val nombreValido = !(binding.editTextNombreViaje.text?.toString().isNullOrEmpty())
        binding.editTextNombreViaje.error = if (nombreValido) null else "Campo obligatorio"

        val imputacionValida = !(binding.autoCompleteImputacionViaje.text?.toString().isNullOrEmpty())
        binding.autoCompleteImputacionViaje.error = if (imputacionValida) null else "Campo obligatorio"

        val monedaValida = !(binding.autoCompleteMonedaViaje.text?.toString().isNullOrEmpty())
        binding.autoCompleteMonedaViaje.error = if (monedaValida) null else "Campo obligatorio"

        val esValido = nombreValido && imputacionValida && monedaValida
        binding.buttonGuardar.isEnabled = esValido
        return esValido
    }

    private fun guardarViaje() {
        val nombreViaje = binding.editTextNombreViaje.text.toString()
        val fechaViaje = binding.editTextFechaViaje.text.toString()
        val monedaDefecto = binding.autoCompleteMonedaViaje.text.toString()
        val imputacionSeleccionadaStr = binding.autoCompleteImputacionViaje.text.toString()

        val imputacionSeleccionada = imputacionesList.find { "PT: ${it.pt} / WP: ${it.wp}" == imputacionSeleccionadaStr }

        if (imputacionSeleccionada != null) {
            val dataIntent = Intent()
            dataIntent.putExtra(EXTRA_VIAJE_NOMBRE, nombreViaje)
            dataIntent.putExtra(EXTRA_VIAJE_FECHA, fechaViaje)
            dataIntent.putExtra(EXTRA_VIAJE_MONEDA_DEFECTO, monedaDefecto)
            dataIntent.putExtra(EXTRA_VIAJE_IMPUTACION_PT, imputacionSeleccionada.pt)
            dataIntent.putExtra(EXTRA_VIAJE_IMPUTACION_WP, imputacionSeleccionada.wp)

            // Modificado: Se devuelve el ID (sea 0L o el ID de edición)
            if (idViajeAEditar != 0L) {
                dataIntent.putExtra(EXTRA_VIAJE_ID, idViajeAEditar)
            }
            setResult(Activity.RESULT_OK, dataIntent)
            finish()
        } else {
            Toast.makeText(this, "Por favor, selecciona una imputación válida", Toast.LENGTH_SHORT).show()
        }
    }

    private fun configurarCampoDeFecha() {
        // Modificado: Se comprueba 0L
        if (idViajeAEditar == 0L) {
            val calendario = Calendar.getInstance()
            val formatoFecha = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            binding.editTextFechaViaje.setText(formatoFecha.format(calendario.time))
        }
        binding.editTextFechaViaje.setOnClickListener {
            mostrarDatePickerDialog()
        }
    }

    private fun mostrarDatePickerDialog() {
        val calendario = Calendar.getInstance()
        val anio = calendario.get(Calendar.YEAR)
        val mes = calendario.get(Calendar.MONTH)
        val dia = calendario.get(Calendar.DAY_OF_MONTH)
        val datePickerDialog = DatePickerDialog(this, { _, year, month, dayOfMonth ->
            val fechaSeleccionada = Calendar.getInstance()
            fechaSeleccionada.set(year, month, dayOfMonth)
            val formatoFecha = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            binding.editTextFechaViaje.setText(formatoFecha.format(fechaSeleccionada.time))
        }, anio, mes, dia)
        datePickerDialog.show()
    }

    private fun cargarOpciones() {
        // Modificado: Se usa "UserPrefs_local"
        val userPrefs = getSharedPreferences("UserPrefs_local", Context.MODE_PRIVATE)

        val monedas = userPrefs.getStringSet("MONEDAS", emptySet())?.toList() ?: emptyList()
        val monedasAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, monedas)
        binding.autoCompleteMonedaViaje.setAdapter(monedasAdapter)

        val imputacionesGuardadas = userPrefs.getStringSet("IMPUTACIONES", emptySet())
        imputacionesList.clear()
        (imputacionesGuardadas ?: emptySet()).forEach {
            val partes = it.split("::")
            if (partes.size == 2) {
                imputacionesList.add(Imputacion(partes[0], partes[1]))
            }
        }
        val imputacionesFormateadas = imputacionesList.map { "PT: ${it.pt} / WP: ${it.wp}" }
        val imputacionesAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, imputacionesFormateadas)
        binding.autoCompleteImputacionViaje.setAdapter(imputacionesAdapter)
    }

    companion object {
        // Modificado: El ID es Long, pero la clave (key) del Intent sigue siendo un String
        const val EXTRA_VIAJE_ID = "EXTRA_VIAJE_ID"
        const val EXTRA_VIAJE_NOMBRE = "EXTRA_VIAJE_NOMBRE"
        const val EXTRA_VIAJE_FECHA = "EXTRA_VIAJE_FECHA"
        const val EXTRA_VIAJE_MONEDA_DEFECTO = "EXTRA_VIAJE_MONEDA_DEFECTO"
        const val EXTRA_VIAJE_IMPUTACION_PT = "EXTRA_VIAJE_IMPUTACION_PT"
        const val EXTRA_VIAJE_IMPUTACION_WP = "EXTRA_VIAJE_IMPUTACION_WP"
    }
}