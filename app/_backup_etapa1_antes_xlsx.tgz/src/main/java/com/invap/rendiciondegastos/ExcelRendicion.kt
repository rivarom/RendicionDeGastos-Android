package com.invap.rendiciondegastos

import jxl.SheetSettings
import jxl.Workbook
import jxl.WorkbookSettings
import jxl.format.Alignment
import jxl.format.Border
import jxl.format.BorderLineStyle
import jxl.format.Colour
import jxl.format.VerticalAlignment
import jxl.write.Blank
import jxl.write.Formula
import jxl.write.Label
import jxl.write.WritableCellFormat
import jxl.write.WritableFont
import jxl.write.WritableSheet
import jxl.write.WritableWorkbook
import java.io.File
import java.util.Locale

/**
 * Genera el Excel (.xls) de la rendición: una hoja por forma de pago.
 * Columnas: Comprobante | Detalle | un importe por tipo de gasto | Moneda | Pesos | Dólares | Tasa de cambio | CC | PT | WP.
 * Los anchos se calculan a partir del contenido (lo justo para que se vea todo).
 */
object ExcelRendicion {

    private const val ALTO_LINEA = 255          // alto de una línea de texto (1/20 de punto)
    private const val ANCHO_MIN_COLUMNA = 6
    private const val ANCHO_MAX_DETALLE = 38
    private const val ANCHO_MIN_TABLA = 70

    fun generar(file: File, viaje: Viaje, gastos: List<Gasto>, tiposConfigurados: List<String>) {
        // Idioma fijo para las fórmulas: en el archivo se guardan como código de función,
        // y Excel las muestra en el idioma del usuario (SUMA, SUM, ...).
        val wbSettings = WorkbookSettings()
        wbSettings.setLocale(Locale.ENGLISH)
        val workbook: WritableWorkbook = Workbook.createWorkbook(file, wbSettings)
        try {
            val formatos = Formatos()
            val tipos = tiposConfigurados.sorted()
            gastos.groupBy { it.formaDePago }.toSortedMap(String.CASE_INSENSITIVE_ORDER).forEach { (forma, lista) ->
                crearHoja(workbook, formatos, viaje, forma, lista, tipos)
            }
            workbook.write()
        } finally {
            runCatching { workbook.close() }
        }
    }

    // ---------------------------------------------------------------- formatos

    private class Formatos {
        val fuenteNegrita = WritableFont(WritableFont.ARIAL, 10, WritableFont.BOLD)
        private val fuenteTitulo = WritableFont(WritableFont.ARIAL, 20, WritableFont.BOLD).also { it.setColour(Colour.GREEN) }
        private val fuente14 = WritableFont(WritableFont.ARIAL, 14, WritableFont.BOLD)

        val pesosNF = jxl.write.NumberFormat("$ #,##0.00")
        val dolaresNF = jxl.write.NumberFormat("#,##0.00")
        val tasaNF = jxl.write.NumberFormat("#,##0.0000")

        val titulo = WritableCellFormat(fuenteTitulo)
        val negrita14 = WritableCellFormat(fuente14)
        val negrita = WritableCellFormat(fuenteNegrita)
        val centroNegrita = WritableCellFormat(fuenteNegrita).also { it.setAlignment(Alignment.CENTRE) }
        val normal = WritableCellFormat()
        val nota = WritableCellFormat(fuenteNegrita).also {
            it.setWrap(true)
            it.setVerticalAlignment(VerticalAlignment.TOP)
        }

        val encabezado = celda(font = fuenteNegrita, centrado = true, wrap = true, fondo = Colour.GRAY_25, borde = BorderLineStyle.MEDIUM)
        val texto = celda()
        val centro = celda(centrado = true)
        val detalle = celda(wrap = true)
        val numero = celda(nf = dolaresNF)
        val pesos = celda(nf = pesosNF)
        val dolares = celda(nf = dolaresNF)
        val dolaresEstimado = celda(nf = dolaresNF, fondo = Colour.PALE_BLUE)
        val tasa = celda(nf = tasaNF)
        val totalEtiqueta = celda(font = fuenteNegrita, borde = BorderLineStyle.MEDIUM)
        val totalPesos = celda(nf = pesosNF, font = fuenteNegrita, borde = BorderLineStyle.MEDIUM)
        val totalDolares = celda(nf = dolaresNF, font = fuenteNegrita, borde = BorderLineStyle.MEDIUM)
        val entradaPesos = celda(nf = pesosNF, fondo = Colour.ICE_BLUE, borde = BorderLineStyle.MEDIUM)
        val entradaDolares = celda(nf = dolaresNF, fondo = Colour.ICE_BLUE, borde = BorderLineStyle.MEDIUM)
        val cajaFirma = celda()

        private fun celda(
            nf: jxl.write.NumberFormat? = null,
            font: WritableFont? = null,
            centrado: Boolean = false,
            wrap: Boolean = false,
            fondo: Colour? = null,
            borde: BorderLineStyle = BorderLineStyle.THIN
        ): WritableCellFormat {
            val f = when {
                font != null && nf != null -> WritableCellFormat(font, nf)
                font != null -> WritableCellFormat(font)
                nf != null -> WritableCellFormat(nf)
                else -> WritableCellFormat()
            }
            f.setBorder(Border.ALL, borde)
            f.setVerticalAlignment(VerticalAlignment.CENTRE)
            if (centrado) f.setAlignment(Alignment.CENTRE)
            if (wrap) f.setWrap(true)
            if (fondo != null) f.setBackground(fondo)
            return f
        }
    }

    // ---------------------------------------------------------------- utilidades

    private fun colLetra(col: Int): String {
        var n = col
        val sb = StringBuilder()
        do {
            sb.insert(0, 'A' + (n % 26))
            n = n / 26 - 1
        } while (n >= 0)
        return sb.toString()
    }

    private fun direccion(col: Int, fila: Int) = "${colLetra(col)}${fila + 1}"

    private fun fmt(v: Double): String = String.format(Locale.US, "%,.2f", v)

    /** Cantidad de líneas que ocupa [texto] en una celda de [ancho] caracteres, cortando por palabras. */
    private fun lineasPara(texto: String, ancho: Int): Int {
        if (texto.isEmpty() || ancho <= 0) return 1
        var lineas = 1
        var actual = 0
        for (palabra in texto.split(' ')) {
            val l = palabra.length
            if (actual == 0) {
                actual = l
            } else if (actual + 1 + l <= ancho) {
                actual += 1 + l
            } else {
                lineas++
                actual = l
            }
            while (actual > ancho) {
                lineas++
                actual -= ancho
            }
        }
        return lineas
    }

    private fun palabraMasLarga(texto: String): Int = texto.split(' ').maxOfOrNull { it.length } ?: 0

    private fun esCredito(forma: String): Boolean =
        forma.contains("Crédito", ignoreCase = true) || forma.contains("Credito", ignoreCase = true)

    /** Texto en una fila, combinado a lo ancho de la tabla y con salto de línea automático. */
    private fun notaCombinada(sheet: WritableSheet, fila: Int, colDesde: Int, colHasta: Int, anchoTotal: Int, texto: String, formato: WritableCellFormat) {
        sheet.mergeCells(colDesde, fila, colHasta, fila)
        sheet.addCell(Label(colDesde, fila, texto, formato))
        // El texto en negrita ocupa ~15% más que el normal
        val lineas = lineasPara(texto, (anchoTotal * 0.87).toInt())
        sheet.setRowView(fila, ALTO_LINEA * lineas + 40)
    }

    // ---------------------------------------------------------------- hoja

    private fun crearHoja(
        workbook: WritableWorkbook,
        f: Formatos,
        viaje: Viaje,
        forma: String,
        lista: List<Gasto>,
        tiposConfigurados: List<String>
    ) {
        val baseHoja = forma.replace(Regex("[\\[\\]:*?/\\\\]"), "").trim().take(28).ifEmpty { "Hoja" }
        var nombreHoja = baseHoja
        var sufijo = 2
        while (workbook.sheetNames.any { it.equals(nombreHoja, ignoreCase = true) }) {
            nombreHoja = "${baseHoja}_$sufijo"
            sufijo++
        }
        val sheet = workbook.createSheet(nombreHoja, workbook.numberOfSheets)
        val settings: SheetSettings = sheet.settings
        settings.setPaperSize(jxl.format.PaperSize.A4)
        settings.setOrientation(jxl.format.PageOrientation.LANDSCAPE)
        settings.setFitWidth(1)

        val credito = esCredito(forma)
        val primerGasto = lista.first()

        // ---- columnas
        val tipos = tiposConfigurados.toMutableList()
        val hayOtros = lista.any { g -> tipos.none { it == g.tipoGasto } }
        if (hayOtros) tipos.add("Otros")
        val c0 = 1
        val colComprobante = c0
        val colDetalle = c0 + 1
        val colTipo0 = c0 + 2
        val colMoneda = colTipo0 + tipos.size
        val colPesos = colMoneda + 1
        val colDolares = colMoneda + 2
        val colTasa = colMoneda + 3
        val colCC = colMoneda + 4
        val colPT = colMoneda + 5
        val colWP = colMoneda + 6
        val ultimaCol = colWP

        val encabezados = mutableListOf("Comprobante", "Detalle")
        encabezados.addAll(tipos)
        encabezados.addAll(listOf("Moneda", "Importe en Pesos", "Importe en Dólares", "Tasa de cambio", "CC", "PT", "WP"))

        fun indiceTipo(g: Gasto): Int {
            val i = tiposConfigurados.indexOf(g.tipoGasto)
            return if (i >= 0) i else tipos.size - 1 // "Otros" es la última
        }
        fun textoDetalle(g: Gasto): String =
            g.descripcion.trim()

        // ---- anchos según contenido
        val anchos = IntArray(ultimaCol + 1)
        encabezados.forEachIndexed { i, h -> anchos[c0 + i] = palabraMasLarga(h) + 2 }
        val sumaPesos = lista.filter { Monedas.esPesos(it.moneda) }.sumOf { it.monto }
        val sumaDolares = lista.sumOf { g ->
            if (Monedas.esDolar(g.moneda)) g.monto else if (Monedas.esExtranjera(g.moneda) && !Monedas.esPesos(g.moneda)) (g.importeDolares ?: 0.0) else 0.0
        }
        anchos[colComprobante] = maxOf(anchos[colComprobante], "TOTALES".length + 2)
        var maxDetalle = 0
        for (g in lista) {
            anchos[colComprobante] = maxOf(anchos[colComprobante], g.tagGasto.length + 2)
            maxDetalle = maxOf(maxDetalle, textoDetalle(g).length)
            val ci = colTipo0 + indiceTipo(g)
            anchos[ci] = maxOf(anchos[ci], fmt(g.monto).length + 2)
            anchos[colMoneda] = maxOf(anchos[colMoneda], g.moneda.length + 2)
            if (Monedas.esPesos(g.moneda)) anchos[colPesos] = maxOf(anchos[colPesos], fmt(g.monto).length + 4)
            val usd = g.dolares()
            if (usd != null && !Monedas.esPesos(g.moneda)) anchos[colDolares] = maxOf(anchos[colDolares], fmt(usd).length + 2)
            if (Monedas.esExtranjera(g.moneda) && !Monedas.esPesos(g.moneda) && usd != null && usd > 0) {
                anchos[colTasa] = maxOf(anchos[colTasa], String.format(Locale.US, "%,.4f", g.monto / usd).length + 2)
            }
            anchos[colCC] = maxOf(anchos[colCC], g.centroCostos.length + 2)
            anchos[colPT] = maxOf(anchos[colPT], g.imputacionPT.length + 2)
            anchos[colWP] = maxOf(anchos[colWP], g.imputacionWP.length + 2)
        }
        anchos[colPesos] = maxOf(anchos[colPesos], fmt(sumaPesos).length + 4, 12)
        anchos[colDolares] = maxOf(anchos[colDolares], fmt(sumaDolares).length + 2, 12)
        anchos[colDetalle] = (maxDetalle + 2).coerceIn(14, ANCHO_MAX_DETALLE)
        for (c in c0..ultimaCol) anchos[c] = maxOf(anchos[c], ANCHO_MIN_COLUMNA)
        var anchoTotal = (c0..ultimaCol).sumOf { anchos[it] }
        if (anchoTotal < ANCHO_MIN_TABLA) {
            anchos[colDetalle] += ANCHO_MIN_TABLA - anchoTotal
            anchoTotal = ANCHO_MIN_TABLA
        }
        sheet.setColumnView(0, 3)
        for (c in c0..ultimaCol) sheet.setColumnView(c, anchos[c])
        sheet.setColumnView(ultimaCol + 1, 3)

        // ---- encabezado de la hoja
        sheet.addCell(Label(c0, 1, "Plazos para la rendición:", f.negrita14))
        notaCombinada(sheet, 2, c0, ultimaCol, anchoTotal, "Los anticipos deberán ser rendidos dentro de la semana de haber concluido el viaje.", f.nota)
        notaCombinada(sheet, 3, c0, ultimaCol, anchoTotal, "En caso de tener que realizar un nuevo desplazamiento, previo a la solicitud de fondos debería proceder a la rendición del anticipo pendiente.", f.nota)
        notaCombinada(sheet, 4, c0, ultimaCol, anchoTotal, "Los anticipos tendrán vencimiento a los 30 días de la fecha de haberse hecho efectivos.", f.nota)
        sheet.setRowView(5, 600)
        sheet.addCell(Label(c0, 5, "INVAP - Rendición de Viajes", f.titulo))
        sheet.mergeCells(c0, 7, ultimaCol, 7)
        sheet.addCell(Label(c0, 7, "RENDICIÓN DE GASTOS REALIZADOS CON", f.centroNegrita))
        sheet.mergeCells(c0, 8, ultimaCol, 8)
        sheet.addCell(Label(c0, 8, forma.uppercase(Locale.getDefault()), f.centroNegrita))

        val persona = primerGasto.nombrePersona.ifBlank { viaje.nombrePersona }
        val legajo = primerGasto.legajo.ifBlank { viaje.legajo }
        val cc = primerGasto.centroCostos.ifBlank { viaje.centroCostos }
        val fechas = if (viaje.fechaFin.isNotBlank()) "${viaje.fecha} al ${viaje.fechaFin}" else viaje.fecha
        sheet.addCell(Label(c0, 10, "Rendición de gastos de:  $persona", f.negrita))
        sheet.addCell(Label(c0, 11, "Viaje:  ${viaje.nombre}", f.negrita))
        sheet.addCell(Label(c0, 12, "Fecha:  $fechas", f.negrita))
        sheet.addCell(Label(c0, 13, "N° de Legajo:  $legajo        CC:  $cc", f.negrita))

        // ---- tabla
        val filaEncabezado = 15
        val lineasEncabezado = encabezados.indices.maxOf { lineasPara(encabezados[it], anchos[c0 + it] - 1) }
        sheet.setRowView(filaEncabezado, ALTO_LINEA * lineasEncabezado + 80)
        encabezados.forEachIndexed { i, h -> sheet.addCell(Label(c0 + i, filaEncabezado, h, f.encabezado)) }

        lista.forEachIndexed { idx, g ->
            val fila = filaEncabezado + 1 + idx
            val extranjera = Monedas.esExtranjera(g.moneda)   // ni pesos ni dólares
            val esPesos = Monedas.esPesos(g.moneda)
            val esDolar = Monedas.esDolar(g.moneda)

            sheet.addCell(Label(colComprobante, fila, g.tagGasto, f.centro))
            val txt = textoDetalle(g)
            sheet.addCell(Label(colDetalle, fila, txt, f.detalle))
            val lineas = lineasPara(txt, anchos[colDetalle] - 1)
            if (lineas > 1) sheet.setRowView(fila, ALTO_LINEA * lineas + 20)

            val colImporte = colTipo0 + indiceTipo(g)
            for (c in colTipo0 until colMoneda) {
                if (c == colImporte) sheet.addCell(jxl.write.Number(c, fila, g.monto, f.numero))
                else sheet.addCell(Blank(c, fila, f.texto))
            }
            sheet.addCell(Label(colMoneda, fila, g.moneda, f.centro))

            if (esPesos) sheet.addCell(jxl.write.Number(colPesos, fila, g.monto, f.pesos))
            else sheet.addCell(Blank(colPesos, fila, f.texto))

            when {
                esDolar -> sheet.addCell(jxl.write.Number(colDolares, fila, g.monto, f.dolares))
                esPesos -> sheet.addCell(Blank(colDolares, fila, f.texto))
                else -> {
                    val usd = g.importeDolares
                    if (usd != null) sheet.addCell(jxl.write.Number(colDolares, fila, usd, if (g.dolaresEstimado) f.dolaresEstimado else f.dolares))
                    else sheet.addCell(Blank(colDolares, fila, f.dolaresEstimado)) // a completar a mano
                }
            }

            if (extranjera) {
                val d = direccion(colDolares, fila)
                val m = direccion(colImporte, fila)
                sheet.addCell(Formula(colTasa, fila, "IF($d>0,$m/$d,0)", f.tasa))
            } else {
                sheet.addCell(Blank(colTasa, fila, f.texto))
            }

            sheet.addCell(Label(colCC, fila, g.centroCostos, f.centro))
            sheet.addCell(Label(colPT, fila, g.imputacionPT, f.centro))
            sheet.addCell(Label(colWP, fila, g.imputacionWP, f.centro))
        }

        // ---- totales
        val filaTotal = filaEncabezado + 1 + lista.size
        sheet.addCell(Label(colComprobante, filaTotal, "TOTALES", f.totalEtiqueta))
        val primera = filaEncabezado + 2   // numeración de Excel (base 1)
        val ultima = filaTotal              // última fila de datos, base 1
        sheet.addCell(Formula(colPesos, filaTotal, "SUM(${colLetra(colPesos)}$primera:${colLetra(colPesos)}$ultima)", f.totalPesos))
        sheet.addCell(Formula(colDolares, filaTotal, "SUM(${colLetra(colDolares)}$primera:${colLetra(colDolares)}$ultima)", f.totalDolares))

        var fila = filaTotal + 1
        if (!credito) {
            val filaRecibido = fila
            val filaSaldo = fila + 1
            val filaDevolver = fila + 2
            fun etiqueta(r: Int, texto: String) {
                sheet.mergeCells(colComprobante, r, colMoneda, r)
                sheet.addCell(Label(colComprobante, r, texto, f.negrita))
            }
            etiqueta(filaRecibido, "Recibido por Tesorería:")
            sheet.addCell(jxl.write.Number(colPesos, filaRecibido, 0.0, f.entradaPesos))
            sheet.addCell(jxl.write.Number(colDolares, filaRecibido, 0.0, f.entradaDolares))
            sheet.addCell(Label(colTasa, filaRecibido, " Completar con el monto de adelanto recibido", f.normal))
            etiqueta(filaSaldo, "Saldo del Anticipo:")
            sheet.addCell(jxl.write.Number(colPesos, filaSaldo, 0.0, f.entradaPesos))
            sheet.addCell(jxl.write.Number(colDolares, filaSaldo, 0.0, f.entradaDolares))
            sheet.addCell(Label(colTasa, filaSaldo, " Completar con lo que te quedó del anticipo", f.normal))
            etiqueta(filaDevolver, "A DEVOLVER/RECUPERAR:")
            sheet.addCell(Formula(colPesos, filaDevolver, "-${direccion(colPesos, filaRecibido)}+${direccion(colPesos, filaTotal)}+${direccion(colPesos, filaSaldo)}", f.totalPesos))
            sheet.addCell(Formula(colDolares, filaDevolver, "-${direccion(colDolares, filaRecibido)}+${direccion(colDolares, filaTotal)}+${direccion(colDolares, filaSaldo)}", f.totalDolares))
            sheet.addCell(Label(colTasa, filaDevolver, " Valor Negativo->Devolver/Positivo->Recuperar", f.normal))
            fila += 3
        }

        // ---- notas sobre monedas extranjeras
        val extranjeros = lista.filter { Monedas.esExtranjera(it.moneda) }
        if (extranjeros.isNotEmpty()) {
            fila++
            val monedas = extranjeros.map { it.moneda }.distinct().joinToString(", ")
            val estimados = extranjeros.count { it.importeDolares != null && it.dolaresEstimado }
            val faltantes = extranjeros.count { it.importeDolares == null }
            val sb = StringBuilder()
            if (credito) {
                sb.append("NOTA: los gastos en $monedas figuran con el importe en dólares cargado en la app; reemplazarlo a mano por el importe en dólares del resumen de la Tarjeta de Crédito.")
            } else {
                sb.append("NOTA: los gastos en $monedas se suman al total en Dólares según el importe en dólares indicado.")
            }
            if (estimados > 0) sb.append(" Las celdas celestes con valor son estimaciones con tasa de cambio de referencia.")
            if (faltantes > 0) sb.append(" Hay $faltantes gasto(s) sin importe en dólares (celda celeste vacía): completar a mano.")
            notaCombinada(sheet, fila, c0, ultimaCol, anchoTotal, sb.toString(), f.nota)
            fila++
        }

        // ---- firmas
        val filaPie = fila + 1
        sheet.setRowView(filaPie, 500)
        sheet.setRowView(filaPie + 2, 500)
        sheet.addCell(Label(colComprobante, filaPie, "Autorizó", f.normal))
        sheet.addCell(Blank(colDetalle, filaPie, f.cajaFirma))
        sheet.addCell(Label(colComprobante, filaPie + 2, "Reviso", f.normal))
        sheet.addCell(Blank(colDetalle, filaPie + 2, f.cajaFirma))
        val colFirmaDesde = ultimaCol - 2
        sheet.mergeCells(colFirmaDesde, filaPie, ultimaCol, filaPie)
        sheet.addCell(Blank(colFirmaDesde, filaPie, f.cajaFirma))
        sheet.addCell(Label(colFirmaDesde, filaPie + 1, "Firma y Aclaración del titular", f.normal))

        // ---- leyendas
        val filaLeyendas = filaPie + 4
        notaCombinada(sheet, filaLeyendas, c0, ultimaCol, anchoTotal, "Los gastos sin comprobante deben ser detallados.", f.nota)
        notaCombinada(sheet, filaLeyendas + 1, c0, ultimaCol, anchoTotal, "En las facturas de restaurantes, cuando son varios comensales, debe colocarse el detalle de los mismos en el reverso.", f.nota)
    }
}
